create database codingon character set utf8mb4 collate utf8mb4_unicode_ci;
show databases;

use codingon;

create table visitor(
	id int primary key auto_increment,
    name varchar(10) not null,
    comment mediumtext
);

desc visitor;

insert into visitor values 
(null, '김상혁','1등'),
(null, '이문현','2등'),
(null, '최한일','3등'),
(null, '박상혁','가나다라'),
(null, '김하나','마바사아'),
(null, '송석현','자차카타');


insert into visitor values(null, '김문산','안녕하세요');

select * from visitor;


create user 'user'@'%' identified by '12345678';
grant all privileges on *.* to 'user'@'%' with grant option;
ALTER USER 'user'@'%' IDENTIFIED WITH mysql_native_password BY '12345678';

flush privileges;

select * from mysql.user;